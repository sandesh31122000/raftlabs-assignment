const table=document.getElementById("table");
        const rows=table.rows.length;
        const cols=table.rows[0].cells.length;
        function is_valid(i,j)
        {
            if(i<0 || i>=8 || j<0 || j>=8)
                {
                    return false;
                }
            return true;
        }
        function color(){
             var x = document.getElementsByTagName('td');
              for(i=0;i<x.length;i++) {
                   x[i].style.backgroundColor ="blueviolet";
                }
            } 
        for(let i=0; i<rows; i++)
        {
            for(let j=0; j<cols; j++)
            {
                table.rows[i].cells[j].onclick=function()
                {
                    color();
                    let curr_row_index=i;
                    let curr_col_index=j;
                    table.rows[i].cells[j].style.backgroundColor = 'coral';
                    const x_dir=[-1,1,-2,-2,2,2,-1,1];
                    const y_dir=[-2,-2,1,-1,-1,1,2,2];
                    let result=[];
                    for(let k=0; k<8; k++)
                    {
                        if(is_valid(i+x_dir[k],j+y_dir[k]))
                        {
                            result.push([curr_row_index+x_dir[k],curr_col_index+y_dir[k]]);
                        }

                    }
                    for(let k=0; k<result.length; k++)
                    {
                        table.rows[result[k][0]].cells[result[k][1]].style.backgroundColor='coral';
                    }
                }
            }
        }