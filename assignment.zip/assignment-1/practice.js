const fs = require("fs");
const csvwriter=require("csv-writer");
var createCsvWriter = csvwriter.createObjectCsvWriter
const Authors = fs.readFileSync("Authors.csv");
const books = fs.readFileSync("book.csv");
const magzines = fs.readFileSync("magzine.csv");
var Author = Authors.toString().split("\r");
var book = books.toString().split("\r");
var magzine = magzines.toString().split("\r");


const Author_result = [];
const book_result = [];
const magzine_result = [];

let Author_head = Author[0].split(';');
let book_head = book[0].split(';');
let magzine_head = magzine[0].split(';');

for (let i = 1; i < Author.length - 1; i++) {
    obj={};
    let value=Author[i].split(';');
    for(let k=0; k<Author_head.length; k++)
    {
        obj[Author_head[k]]=value[k].replace(/\n/g,'');
    }
    Author_result.push(obj);
}
for (let i = 1; i < book.length - 1; i++) {
    obj={};
    let value=book[i].split(';');
    for(let k=0; k<book_head.length; k++)
    {
        obj[book_head[k]]=value[k].replace(/\n/g,'');
    }
    book_result.push(obj);
}
for (let i = 1; i < magzine.length - 1; i++) {
    obj={};
    let value=magzine[i].split(';');
    for(let k=0; k<magzine_head.length; k++)
    {
        obj[magzine_head[k]]=value[k].replace(/\n/g,'');
    }
    magzine_result.push(obj);
}
let books_magzine_data={
    book:book_result,
    magzine:magzine_result
};
//Print out all books and magazines (on either console UI) with all their details (with a meaningful output format).
function show_data()
{
    console.log(books_magzine_data);
}
//Find a book or magazine by its ISBN.
function isbn_data_find (data,isbn)
{
    let ans  = books_magzine_data[data].filter(function(data_value){
        if(data_value.isbn==isbn)
        {
            return data_value;
        }

    }).map(dv=>dv.title);
    console.log(ans);
}
//Find all books and magazines by their authors’ email.
function email_data_find(email)
{
    let book_value=books_magzine_data["book"].filter((data_value)=>data_value.authors==email).map((dv)=>dv.title);
    let magzine_value=books_magzine_data["magzine"].filter((data_value)=>data_value.author==email).map((dv)=>dv.title);
    console.log(book_value+magzine_value);
}
//Print out all books and magazines with all their details sorted by title. This sort should be done for books and magazines together.
function sorted()
{
    let ans=[];
    books_magzine_data["book"].forEach(function(data){
        ans.push(data);
    })
    books_magzine_data["magzine"].forEach(function(data){
        ans.push(data);
    })
    let result= ans.sort(function(c1,c2){
        if(c1.title > c2.title)
        {
            return 1;
        }
        else{
            return -1;
        }
    })
    console.log(result);

}
//Add a book and a magazine to the data structure of your software and export it to a new CSV file.
function merge()
{
    let ans=[];
    books_magzine_data["book"].forEach(function(data){
        data.type="book";
        data.publishedAt="";
        ans.push(data);
    })
    books_magzine_data["magzine"].forEach(function(data){
        data.type="magzine";
        data.description="";
        ans.push(data);
    })
    console.log(ans);
    const csvWriter = createCsvWriter({
        path: './result.csv',
        header: ['title','isbn','authors','publishedAt','type','description'
        ]
    
      });
      csvWriter
      .writeRecords(ans)
      .then(()=> console.log('Data uploaded into csv successfully'));
    

}
merge();


